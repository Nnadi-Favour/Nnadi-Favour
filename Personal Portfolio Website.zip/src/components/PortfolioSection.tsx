import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ExternalLink, Github, Figma, BookOpen, Users } from 'lucide-react';

export function PortfolioSection() {
  const projects = [
    {
      title: "UI/UX Design Projects",
      description: "Prototypes, redesigns, and app mockups showcasing user-centered design principles and modern interface patterns. Explore my design process from wireframes to high-fidelity prototypes.",
      type: "UI/UX Design",
      link: "https://www.figma.com/@that_techgirl",
      icon: Figma,
      tags: ["Prototyping", "UI Design", "UX Research", "Wireframing"]
    },
    {
      title: "App Redesigns",
      description: "Mobile and web application redesigns focusing on improved user experience, accessibility, and modern design standards. See how I approach design challenges.",
      type: "Design Portfolio",
      link: "https://www.figma.com/@that_techgirl",
      icon: Figma,
      tags: ["Mobile Design", "Web Design", "Usability", "Prototyping"]
    },
    {
      title: "Design Systems",
      description: "Comprehensive design systems and component libraries created for various projects, demonstrating consistency and scalability in design.",
      type: "Design Systems",
      link: "https://www.figma.com/@that_techgirl",
      icon: Figma,
      tags: ["Design Systems", "Component Library", "Figma", "UI Components"]
    }
  ];

  const githubProjects = [
    {
      title: "Development Projects",
      description: "Responsive websites, mobile apps, and Java projects showcasing clean code practices and modern development techniques. See my coding skills in action.",
      type: "Web & Mobile Development",
      link: "https://github.com/nnadi-favour",
      icon: Github,
      tags: ["Web Development", "Mobile Apps", "Java", "Responsive Design"]
    },
    {
      title: "Android Applications",
      description: "Native Android applications built with Java and Android Studio, demonstrating mobile development skills and user interface design.",
      type: "Mobile Development",
      link: "https://github.com/nnadi-favour",
      icon: Github,
      tags: ["Android", "Java", "Android Studio", "Mobile UI"]
    },
    {
      title: "Frontend Projects",
      description: "Web development projects using HTML, CSS, JavaScript, and Bootstrap. Showcasing responsive design and frontend development expertise.",
      type: "Frontend Development",
      link: "https://github.com/nnadi-favour",
      icon: Github,
      tags: ["HTML", "CSS", "JavaScript", "Bootstrap"]
    }
  ];

  const educationProjects = [
    {
      title: "Google Workspace Workshops",
      description: "Comprehensive training programs designed to help educators effectively adopt and utilize Google Workspace tools for enhanced productivity and collaboration.",
      type: "Digital Education",
      icon: BookOpen,
      tags: ["Google Workspace", "Teacher Training", "Digital Adoption", "Remote Learning"]
    },
    {
      title: "Digital Transformation Programs",
      description: "Change management initiatives helping organizations transition to digital workflows, with focus on user adoption and sustainable technology integration.",
      type: "Change Management",
      icon: Users,
      tags: ["Digital Transformation", "Change Management", "Training", "Technology Adoption"]
    }
  ];

  return (
    <section id="portfolio" className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">Portfolio</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore my design work on Figma and development projects on GitHub.
          </p>
        </motion.div>

        {/* Figma Portfolio */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-8">
            <Figma className="h-6 w-6 text-purple-600 mr-3" />
            <h3 className="text-2xl">Design Portfolio</h3>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full group hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <project.icon className="h-5 w-5 text-purple-600 mr-2" />
                      <Badge variant="secondary" className="text-xs">
                        {project.type}
                      </Badge>
                    </div>
                    
                    <h4 className="mb-3">{project.title}</h4>
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                      {project.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300"
                      onClick={() => window.open(project.link, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View on Figma
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* GitHub Projects */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-8">
            <Github className="h-6 w-6 text-gray-800 mr-3" />
            <h3 className="text-2xl">Development Projects</h3>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {githubProjects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full group hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <project.icon className="h-5 w-5 text-gray-800 mr-2" />
                      <Badge variant="secondary" className="text-xs">
                        {project.type}
                      </Badge>
                    </div>
                    
                    <h4 className="mb-3">{project.title}</h4>
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                      {project.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300"
                      onClick={() => window.open(project.link, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View on GitHub
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Digital Education Projects */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-8">
            <BookOpen className="h-6 w-6 text-blue-600 mr-3" />
            <h3 className="text-2xl">Digital Education Projects</h3>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {educationProjects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full group hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <project.icon className="h-5 w-5 text-blue-600 mr-2" />
                      <Badge variant="secondary" className="text-xs">
                        {project.type}
                      </Badge>
                    </div>
                    
                    <h4 className="mb-3">{project.title}</h4>
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                      {project.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}