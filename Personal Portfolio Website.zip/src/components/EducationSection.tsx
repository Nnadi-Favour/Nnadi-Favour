import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar, MapPin, GraduationCap } from 'lucide-react';

export function EducationSection() {
  const education = [
    {
      title: "Advanced Diploma in Software Engineering (ADSE)",
      institution: "Aptech Computer Education",
      period: "2020 – 2023",
      location: "Nigeria",
      description: "Comprehensive software engineering program covering full-stack development, mobile app development, and modern programming practices.",
      achievements: [
        "Focus: Java, Android Development, Web Development (HTML, CSS, JS), Database Management",
        "Completed advanced courses in Java programming and Android development",
        "Developed multiple web and mobile applications during coursework",
        "Mastered database management and software engineering principles"
      ],
      technologies: ["Java", "Android Studio", "HTML", "CSS", "JavaScript", "Database Management", "Software Engineering"]
    },
    {
      title: "Internship",
      institution: "Aptech Computer Education",
      period: "2023 – 2024",
      location: "Nigeria",
      description: "Hands-on internship program focusing on practical application of software development skills in real-world projects and team collaboration environments.",
      achievements: [
        "Hands-on projects in web and mobile app development",
        "Applied classroom knowledge to real-world projects and team collaborations",
        "Gained experience in project management and agile development practices",
        "Contributed to multiple client projects under mentorship"
      ],
      technologies: ["Project Management", "Team Collaboration", "Agile Development", "Client Projects", "Mentorship"]
    }
  ];

  return (
    <section id="education" className="py-20">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">Education</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My educational background and formal training in software engineering and development.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border hidden md:block" />
            
            <div className="space-y-12">
              {education.map((edu, index) => (
                <motion.div
                  key={edu.title}
                  className="relative"
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-6 top-6 w-4 h-4 bg-background border-2 border-primary rounded-full z-10 hidden md:block" />
                  
                  <div className="md:ml-20">
                    <Card className="group hover:shadow-lg transition-all duration-300">
                      <CardContent className="p-8">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center">
                            <div className="p-2 rounded-lg bg-muted mr-4 md:hidden">
                              <GraduationCap className="h-5 w-5 text-green-600" />
                            </div>
                            <div>
                              <h3 className="text-xl mb-1">{edu.title}</h3>
                              <p className="text-primary">{edu.institution}</p>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            Education
                          </Badge>
                        </div>
                        
                        <div className="flex items-center text-muted-foreground text-sm mb-4 space-x-4">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            {edu.period}
                          </div>
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {edu.location}
                          </div>
                        </div>
                        
                        <p className="text-muted-foreground mb-6 leading-relaxed">
                          {edu.description}
                        </p>
                        
                        <div className="space-y-4">
                          <div>
                            <h4 className="mb-3">Key Learning Areas:</h4>
                            <div className="grid md:grid-cols-2 gap-2">
                              {edu.achievements.map((achievement, achIndex) => (
                                <motion.div
                                  key={achievement}
                                  className="flex items-start"
                                  initial={{ opacity: 0, x: -20 }}
                                  whileInView={{ opacity: 1, x: 0 }}
                                  transition={{ duration: 0.3, delay: (index * 0.2) + (achIndex * 0.1) }}
                                  viewport={{ once: true }}
                                >
                                  <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                                  <span className="text-muted-foreground text-sm">{achievement}</span>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="mb-3">Technologies & Skills Learned:</h4>
                            <div className="flex flex-wrap gap-2">
                              {edu.technologies.map((tech, techIndex) => (
                                <motion.div
                                  key={tech}
                                  initial={{ opacity: 0, scale: 0.8 }}
                                  whileInView={{ opacity: 1, scale: 1 }}
                                  transition={{ duration: 0.3, delay: (index * 0.2) + (techIndex * 0.05) }}
                                  viewport={{ once: true }}
                                >
                                  <Badge variant="secondary" className="text-xs">
                                    {tech}
                                  </Badge>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}