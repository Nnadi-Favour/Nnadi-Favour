import { motion } from 'motion/react';
import { Heart } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="py-12 border-t border-border bg-background">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.button
            onClick={scrollToTop}
            className="mb-6 text-primary hover:text-primary/80 transition-colors cursor-pointer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="tracking-wide">Favour Nnadi</span>
          </motion.button>
          
          <div className="flex items-center justify-center text-muted-foreground text-sm">
            <span>© {currentYear} Made with </span>
            <motion.div
              className="mx-1"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity, ease: "easeInOut" }}
            >
              <Heart className="h-4 w-4 text-red-500 fill-current" />
            </motion.div>
            <span> by Favour Nnadi</span>
          </div>
          
          <p className="text-xs text-muted-foreground mt-2">
            UI/UX Designer | Software Engineer | Google Certified Educator
          </p>
        </motion.div>
      </div>
    </footer>
  );
}