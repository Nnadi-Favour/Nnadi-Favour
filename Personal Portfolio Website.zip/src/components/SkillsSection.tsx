import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { 
  Palette, 
  Code, 
  Smartphone, 
  Users, 
  Zap,
  Figma,
  Monitor,
  BookOpen
} from 'lucide-react';

export function SkillsSection() {
  const skillCategories = [
    {
      icon: Palette,
      title: "UI/UX Design",
      skills: ["Figma", "Wireframing", "Prototyping", "Usability Testing"],
      color: "text-blue-600"
    },
    {
      icon: Code,
      title: "Frontend Development",
      skills: ["HTML", "CSS", "JavaScript", "Bootstrap"],
      color: "text-green-600"
    },
    {
      icon: Smartphone,
      title: "Mobile Development",
      skills: ["Java", "Android Studio"],
      color: "text-purple-600"
    },
    {
      icon: BookOpen,
      title: "Google Workspace",
      skills: ["Classroom", "Docs", "Slides", "Meet", "Sites", "Forms"],
      color: "text-orange-600"
    },
    {
      icon: Users,
      title: "Collaboration",
      skills: ["Design Thinking", "Agile Practices", "Project Management", "Remote Training"],
      color: "text-red-600"
    }
  ];

  return (
    <section id="skills" className="py-20">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">Skills & Expertise</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A comprehensive overview of my technical skills and areas of expertise.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-8">
                  <motion.div
                    className="flex items-center mb-6"
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className={`p-3 rounded-lg bg-muted mr-4 group-hover:scale-110 transition-transform duration-300`}>
                      <category.icon className={`h-6 w-6 ${category.color}`} />
                    </div>
                    <h3 className="text-xl">{category.title}</h3>
                  </motion.div>
                  
                  <div className="space-y-3">
                    {category.skills.map((skill, skillIndex) => (
                      <motion.div
                        key={skill}
                        className="flex items-center"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: (index * 0.1) + (skillIndex * 0.05) }}
                        viewport={{ once: true }}
                      >
                        <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                        <span className="text-muted-foreground">{skill}</span>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Additional Stats */}
        <motion.div
          className="grid md:grid-cols-3 gap-8 mt-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          {[
            { number: "3+", label: "Years Experience" },
            { number: "50+", label: "Educators Trained" },
            { number: "100%", label: "Client Satisfaction" }
          ].map((stat, index) => (
            <div key={stat.label} className="text-center">
              <motion.div
                className="text-3xl md:text-4xl text-primary mb-2"
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                {stat.number}
              </motion.div>
              <p className="text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}