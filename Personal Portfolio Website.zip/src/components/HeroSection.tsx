import { motion } from 'motion/react';
import { Button } from './ui/button';
import professionalPhoto from 'figma:asset/9df0ef16cc3a091ebace09c7885168e05296fdda.png';

export function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center pt-20 pb-16">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              <p className="text-primary mb-2">Hello, I'm</p>
              <h1 className="text-4xl md:text-6xl mb-4">Favour Nnadi</h1>
              <div className="text-xl md:text-2xl text-muted-foreground mb-6">
                <span className="text-primary">UI/UX Designer</span> | 
                <span className="text-primary"> Software Engineer</span> | 
                <span className="text-primary"> Google Certified Educator</span>
              </div>
            </motion.div>
            
            <motion.p
              className="text-lg text-muted-foreground leading-relaxed max-w-2xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              Passionate about designing intuitive digital experiences and empowering educators through technology. 
              I combine UI/UX design, software engineering, and digital education expertise to deliver solutions 
              that delight users and enhance learning outcomes.
            </motion.p>
            
            <motion.div
              className="flex flex-wrap gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.6 }}
            >
              <Button 
                onClick={() => scrollToSection('portfolio')}
                className="px-8 py-3"
              >
                View My Work
              </Button>
              <Button 
                variant="outline"
                onClick={() => scrollToSection('contact')}
                className="px-8 py-3"
              >
                Get In Touch
              </Button>
            </motion.div>
          </motion.div>

          {/* Profile Image */}
          <motion.div
            className="flex justify-center lg:justify-end"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <div className="relative">
              <motion.div
                className="w-80 h-80 rounded-full overflow-hidden border-4 border-primary/10 shadow-2xl"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              >
                <img
                  src={professionalPhoto}
                  alt="Favour Nnadi - Professional Photo"
                  className="w-full h-full object-cover"
                />
              </motion.div>
              <motion.div
                className="absolute -top-4 -right-4 w-16 h-16 bg-primary/10 rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              />
              <motion.div
                className="absolute -bottom-6 -left-6 w-12 h-12 bg-primary/5 rounded-full"
                animate={{ rotate: -360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}