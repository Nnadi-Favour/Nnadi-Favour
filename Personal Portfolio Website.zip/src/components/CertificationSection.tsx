import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar, MapPin, Award, CheckCircle } from 'lucide-react';

export function CertificationSection() {
  return (
    <section id="certification" className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">Certification</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Professional certification demonstrating expertise in Google Workspace for Education.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="group hover:shadow-lg transition-all duration-300">
              <CardContent className="p-8">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-lg bg-purple-100 mr-4">
                      <Award className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl mb-1">Google Certified Educator Level 1</h3>
                      <p className="text-primary">Google for Education</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    Certification
                  </Badge>
                </div>
                
                <div className="flex items-center text-muted-foreground text-sm mb-6 space-x-4">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    2025
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    Online
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Demonstrated expertise in Google Workspace for Education tools and methodologies. 
                  This certification validates my ability to effectively integrate technology into 
                  educational environments and train others on Google's suite of educational tools.
                </p>
                
                <div className="space-y-6">
                  <div>
                    <h4 className="mb-4">Certification Areas:</h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      {[
                        "Google Classroom management",
                        "Google Drive collaboration", 
                        "Google Meet and Sites",
                        "Google Forms"
                      ].map((area, index) => (
                        <motion.div
                          key={area}
                          className="flex items-center"
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          viewport={{ once: true }}
                        >
                          <CheckCircle className="h-5 w-5 text-green-600 mr-3 flex-shrink-0" />
                          <span className="text-muted-foreground">{area}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="mb-3">Skills Validated:</h4>
                    <div className="flex flex-wrap gap-2">
                      {[
                        "Digital Pedagogy",
                        "Technology Integration", 
                        "Educator Training",
                        "Google Workspace Administration",
                        "Remote Learning",
                        "Digital Collaboration"
                      ].map((skill, skillIndex) => (
                        <motion.div
                          key={skill}
                          initial={{ opacity: 0, scale: 0.8 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: skillIndex * 0.05 }}
                          viewport={{ once: true }}
                        >
                          <Badge variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}