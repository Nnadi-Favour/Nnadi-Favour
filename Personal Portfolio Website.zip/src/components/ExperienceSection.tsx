import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar, MapPin, Briefcase } from 'lucide-react';

export function ExperienceSection() {
  return (
    <section id="experience" className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">Experience</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My professional experience in digital transformation and educator training.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="group hover:shadow-lg transition-all duration-300">
              <CardContent className="p-8">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center">
                    <div className="p-3 rounded-lg bg-blue-100 mr-4">
                      <Briefcase className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl mb-1">Change Management Officer & Google for Education Trainer</h3>
                      <p className="text-primary">Current Role</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    Current Position
                  </Badge>
                </div>
                
                <div className="flex items-center text-muted-foreground text-sm mb-4 space-x-4">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    2025 – Present
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    Remote
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Leading digital transformation initiatives and training educators on Google Workspace tools. 
                  Responsible for helping organizations adopt technology effectively while ensuring smooth 
                  transitions and high user adoption rates.
                </p>
                
                <div className="space-y-6">
                  <div>
                    <h4 className="mb-4">Key Achievements:</h4>
                    <div className="grid md:grid-cols-2 gap-3">
                      {[
                        "Trained 50+ educators on Google Workspace",
                        "Developed training programs and documentation", 
                        "Achieved 95% technology adoption rate across trained organizations",
                        "Led successful digital transformation initiatives"
                      ].map((achievement, index) => (
                        <motion.div
                          key={achievement}
                          className="flex items-start"
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          viewport={{ once: true }}
                        >
                          <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                          <span className="text-muted-foreground text-sm">{achievement}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="mb-3">Core Responsibilities:</h4>
                    <div className="flex flex-wrap gap-2">
                      {[
                        "Google Workspace Training",
                        "Change Management", 
                        "Digital Transformation",
                        "Educator Support",
                        "Training Development",
                        "Technology Adoption",
                        "Remote Training Delivery"
                      ].map((responsibility, index) => (
                        <motion.div
                          key={responsibility}
                          initial={{ opacity: 0, scale: 0.8 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          viewport={{ once: true }}
                        >
                          <Badge variant="secondary" className="text-xs">
                            {responsibility}
                          </Badge>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}