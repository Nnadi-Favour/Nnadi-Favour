import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Mail, Linkedin, Github, Figma, ExternalLink } from 'lucide-react';

export function ContactSection() {
  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "favour.nnadi.remote@gmail.com",
      link: "mailto:favour.nnadi.remote@gmail.com",
      color: "text-red-600"
    },
    {
      icon: Linkedin,
      label: "LinkedIn",
      value: "/in/favour-nnadi-b2912522b/",
      link: "https://www.linkedin.com/in/favour-nnadi-b2912522b/",
      color: "text-blue-600"
    },
    {
      icon: Figma,
      label: "Figma Portfolio",
      value: "@that_techgirl",
      link: "https://www.figma.com/@that_techgirl",
      color: "text-purple-600"
    },
    {
      icon: Github,
      label: "GitHub",
      value: "github.com/nnadi-favour",
      link: "https://github.com/nnadi-favour",
      color: "text-gray-800"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">Let's Connect</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Ready to collaborate on your next project or discuss opportunities? 
            I'd love to hear from you.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Contact Information */}
            <motion.div
              className="space-y-8"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Card>
                <CardContent className="p-8">
                  <h3 className="mb-6">Get In Touch</h3>
                  <div className="space-y-6">
                    {contactInfo.map((contact, index) => (
                      <motion.div
                        key={contact.label}
                        className="group cursor-pointer"
                        onClick={() => window.open(contact.link, '_blank')}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        viewport={{ once: true }}
                        whileHover={{ x: 10 }}
                      >
                        <div className="flex items-center p-4 rounded-lg border border-transparent group-hover:border-border group-hover:bg-muted/50 transition-all duration-300">
                          <div className={`p-3 rounded-lg bg-muted mr-4 group-hover:scale-110 transition-transform duration-300`}>
                            <contact.icon className={`h-5 w-5 ${contact.color}`} />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm text-muted-foreground">{contact.label}</p>
                            <p className="text-foreground group-hover:text-primary transition-colors duration-300">
                              {contact.value}
                            </p>
                          </div>
                          <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardContent className="p-8">
                    <h4 className="mb-4">What I Can Help With</h4>
                    <div className="space-y-3 text-muted-foreground">
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                        <span>UI/UX Design & Prototyping</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                        <span>Frontend Development</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                        <span>Mobile App Development</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                        <span>Google Workspace Training</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                        <span>Digital Education Solutions</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>

            {/* Call to Action */}
            <motion.div
              className="space-y-8"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <Card>
                <CardContent className="p-8 text-center">
                  <motion.div
                    className="mb-6"
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Mail className="h-10 w-10 text-primary" />
                    </div>
                    <h3 className="mb-4">Ready to Start a Project?</h3>
                    <p className="text-muted-foreground mb-6">
                      Whether you need UI/UX design, frontend development, mobile apps, or Google Workspace 
                      training, I'm here to help bring your vision to life with user-centered solutions.
                    </p>
                  </motion.div>
                  
                  <div className="space-y-4">
                    <Button
                      className="w-full"
                      onClick={() => window.open('mailto:favour.nnadi.remote@gmail.com', '_blank')}
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Send Email
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => window.open('https://www.linkedin.com/in/favour-nnadi-b2912522b/', '_blank')}
                    >
                      <Linkedin className="h-4 w-4 mr-2" />
                      Connect on LinkedIn
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-8">
                  <h4 className="mb-4">Current Availability</h4>
                  <div className="flex items-center mb-4">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-3" />
                    <span className="text-green-600">Available for new projects</span>
                  </div>
                  <p className="text-muted-foreground text-sm">
                    I'm currently accepting new freelance projects and consulting opportunities. 
                    Remote work preferred, but open to discussions for the right projects.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}