import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

export function AboutSection() {
  const certifications = [
    'Google Certified Educator Level 1',
    'Advanced Diploma in Software Engineering (ADSE)',
    'Java Programming',
    'Android Development',
    'UI/UX Design'
  ];

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl mb-4">About Me</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Learn more about my journey, expertise, and passion for technology and education.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card>
              <CardContent className="p-8">
                <h3 className="mb-4">My Journey</h3>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    I am passionate about designing intuitive digital experiences and empowering educators through technology. 
                    I combine UI/UX design, software engineering, and digital education expertise to deliver solutions 
                    that delight users and enhance learning outcomes.
                  </p>
                  <p>
                    Currently, I work as a Change Management Officer, helping organizations adopt Google Workspace tools 
                    for effective digital transformation. My approach focuses on making technology accessible and ensuring 
                    smooth transitions that empower teams to work more efficiently.
                  </p>
                  <p>
                    My expertise spans across designing user-centered interfaces, developing robust applications, 
                    and training educators to leverage technology for better learning outcomes. I believe in creating 
                    solutions that not only look great but also solve real problems for users.
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Card>
              <CardContent className="p-8">
                <h3 className="mb-4">Core Values</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="mb-2">User-Centered Design</h4>
                    <p className="text-muted-foreground">
                      Every solution starts with understanding user needs and creating experiences 
                      that are both beautiful and functional.
                    </p>
                  </div>
                  <div>
                    <h4 className="mb-2">Continuous Learning</h4>
                    <p className="text-muted-foreground">
                      Technology evolves rapidly, and I believe in staying current with the latest 
                      tools, methodologies, and best practices.
                    </p>
                  </div>
                  <div>
                    <h4 className="mb-2">Empowerment Through Technology</h4>
                    <p className="text-muted-foreground">
                      Technology should empower people to achieve more, and I'm passionate about 
                      making complex tools accessible to everyone.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h3 className="mb-4">Certifications & Recognition</h3>
                <div className="flex flex-wrap gap-2">
                  {certifications.map((cert, index) => (
                    <motion.div
                      key={cert}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <Badge variant="secondary" className="text-xs">
                        {cert}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}